
let chicken = document.getElementById("chicken");
let cow = document.getElementById("cow");
let pig = document.getElementById("pig");
let result = document.getElementById("result");

const c = 2;
const p = 4;
const co = 4;


total = () => {
    const chickens = Number(chicken.value);
    const cows = Number(cow.value);
    const pigs = Number(pig.value);

    const t = chickens * c + cows * co + pigs * p;
    result.innerHTML = t + " " + "Legs";
};